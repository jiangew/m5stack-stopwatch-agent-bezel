import { planAction } from './dom-adapter.js';

const inject = ['shortcuts', 'slots', 'configForms', 'layout', 'sessions', 'workspaces'];
const COMMANDS = Object.freeze([
  ['previousThread', 'Previous existing thread', 'ArrowUp'],
  ['nextThread', 'Next existing thread', 'ArrowDown'],
  ['toggleView', 'Toggle Chat / Trajectory', 'ArrowRight'],
]);
function factsFrom(ctx) {
  // Only readiness booleans/phase and registry IDs; never session/workspace data.
  return {
    mainPanel: ctx.layout.panelInfo.getSnapshot().activePanelId,
    sessionsPhase: ctx.sessions.list.getSnapshot().phase,
    workspacesPhase: ctx.workspaces.list.getSnapshot().phase,
    developerTools: ctx.configForms.developerTools.enabled.getSnapshot(),
    viewIds: ctx.slots.entries('conversation.view').map(entry => entry.options.id),
  };
}
function registerCommands(ctx, document) {
  let disposed = false;
  let pending = null;
  const releases = [];
  const plan = (context, action) => {
    if (disposed) return null;
    if (pending) {
      const { element, kind, owner, count } = pending;
      const acknowledged = !element.isConnected || (kind === 'expand'
        ? element.getAttribute('aria-expanded') === 'true' || owner.querySelectorAll('[data-row-key]').length !== count
        : element.getAttribute('aria-selected') === 'true');
      if (!acknowledged) return null;
      if (kind === 'thread' && element.isConnected) {
        const bodies = document.querySelectorAll('[data-conversation-content]');
        if (bodies.length !== 1 || bodies[0].getAttribute('data-conversation-session') !== element.getAttribute('data-row-key').slice(8) || bodies[0].getAttribute('data-content-phase') === 'settling') return null;
      }
      pending = null;
    }
    try { return planAction(document, context, factsFrom(ctx), action); }
    catch { return null; }
  };
  try {
    for (const [action, label, code] of COMMANDS) {
      const defaults = Object.fromEntries(['desktop', 'web'].flatMap(runtime => ['macos', 'windows', 'linux'].map(platform => [
        `${runtime}:${platform}`, { code, modifiers: ['control', 'alt'] },
      ])));
      releases.push(ctx.shortcuts.register({
        id: `agentbezel.${action}`, label: () => label, aliases: [], defaults,
        regions: ['page', 'editable'], modals: [],
        resolve(context) {
          const initial = plan(context, action);
          if (!initial) return { status: 'blocked', reason: 'AgentBezel: focused, unambiguous ready main view required (or list boundary).' };
          return {
            status: 'handled',
            run() {
              // Re-read ALL guards and recompute the target immediately before click.
              // A changed row/tab target invalidates the action instead of retargeting.
              const current = plan(context, action);
              if (current && current.element === initial.element && current.kind === initial.kind) {
                const owner = current.element.closest('[role="tree"]') ?? current.element.parentElement;
                pending = { ...current, owner, count: owner.querySelectorAll('[data-row-key]').length };
                current.element.click();
              }
            },
          };
        },
      }));
    }
  } catch (error) {
    for (const release of releases.reverse()) release();
    throw error;
  }
  return () => {
    disposed = true;
    for (const release of releases.reverse()) release();
  };
}
function apply(ctx) {
  ctx.effect(() => registerCommands(ctx, globalThis.document), 'agentbezel: three navigation commands');
}
export { inject, apply, registerCommands, factsFrom };
