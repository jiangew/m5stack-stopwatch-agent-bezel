// Optional read-only conformance check. Usage: node scripts/check-installed-contract.mjs PATH_TO_DSH_NODE_MODULES
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const modules = process.argv[2];
if (!modules) throw new Error('Pass inspected DSH node_modules directory (no installation performed).');
const source = readFileSync(resolve(modules, '@deepseek-ai/dsh-client-shortcuts/lib/client.js'), 'utf8');
// Execute only pure copied binding definitions, never the host or client plugin.
const binding = source.slice(source.indexOf('const keyNames ='), source.indexOf('//#region lib/types/client/dom.js'));
const pure = binding.slice(0, binding.indexOf('var ShortcutsStore'));
// Specifically take pure functions through bindingIssue; no class/service boot.
const end = pure.indexOf('/**\n\t\t* Select the command owner');
if (end < 0) throw new Error('Unsupported inspected shortcut structure');
const policy = vm.runInNewContext(`(() => { ${pure.slice(0, end)}; return { bindingIssue, normalizeBinding }; })()`);
const rows = [];
for (const runtime of ['desktop', 'web']) for (const platform of ['macos', 'windows', 'linux']) {
  const issue = policy.bindingIssue(policy.normalizeBinding({ code: 'ArrowDown', modifiers: ['control', 'alt'] }, platform), runtime, platform);
  const expected = runtime === 'desktop' && platform !== 'linux' || runtime === 'web' && platform === 'windows' ? null : 'reserved';
  assert.equal(issue, expected);
  rows.push(`${runtime}:${platform} = ${issue ?? 'allowed'}`);
}
assert.match(source, /if \(!gesture\.repeat\) resolution\.run\(\)/);
const workspace = readFileSync(resolve(modules, '@deepseek-ai/dsh-client-ui-workspace/lib/client.js'), 'utf8');
for (const marker of ['_7514NG_groupSection', 'jJkEga_sessionRow', 'jJkEga_projectRow', '"data-row-key": `overflow:${group.key}`', '"aria-selected": selected']) assert.ok(workspace.includes(marker), marker);
const conversation = readFileSync(resolve(modules, '@deepseek-ai/dsh-client-ui-conversation/lib/client.js'), 'utf8');
for (const marker of ['ST7X_W_root', '"data-conversation-tabs": ""', 'slots.entries("conversation.view")', 'ctx.configForms.developerTools.enabled.getSnapshot()']) assert.ok(conversation.includes(marker), marker);
console.log(`Read-only source contract check passed.\n${rows.join('\n')}\nHeld repeats are suppressed by the installed service.`);
